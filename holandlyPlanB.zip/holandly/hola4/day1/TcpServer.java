package day1;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * File: TcpServer.java
 *
 * This is a simple server program, which listens to clients' connections,
 * receives the message of a client, and responds with the same message back.
 * The class uses java Server Socket class listen to connections and
 * Socket class to communicate with a client.
 * When "end" message is read, a client connection is stopped.
 *
 * @author Andrii Zelenetskyi
 * @version 1.0
 */
public class TcpServer {

    /*random free local port*/
    private static final int PORT = 8189;

    public static void main(String[] args) {
        try(ServerSocket socket = new ServerSocket(PORT)){
            while(true) {
                new clientThread(socket.accept()).run();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This is an inner class, which helps in handling multiple clients by the server.
     * Requests of a single client are checked and responded to in it.
     */
    private static class clientThread implements Runnable {
        /*socket, accepted by ServerSocket*/
        Socket client;

        /**
         * Constructs a client handling thread
         * @param socket accepted socket
         */
        private clientThread(Socket socket) {
            client = socket;
        }

        @Override
        public void run() {
            try{
                System.out.println(client.getRemoteSocketAddress());
                Scanner in = new Scanner(client.getInputStream());
                PrintStream out = new PrintStream(client.getOutputStream());
                String line;
                while (in.hasNextLine()) {
                    line = in.nextLine();
                    if(line.equals("end")) {
                        break;
                    }
                    System.out.println(line);
                    out.println(line);
                }
                in.close();
                out.close();
                client.close();
            } catch(IOException e) {
                e.getMessage();
            }

        }
    }
}
