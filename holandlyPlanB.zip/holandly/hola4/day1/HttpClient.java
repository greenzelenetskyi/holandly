package day1;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 *File: HttpClient.java
 *
 * This is a simple http client program, which connects with a server,
 * and sends an HTTP request with a message, and after it receives
 * the message back, it terminates its operation.
 *
 * @author Andrii Zelenetskyi
 * @version 1.0
 */
public class HttpClient {

    /*Request sending a message, which should be sent back*/
    private static final String REQUEST = "TRACE";
    /*second parameter in HTTP request*/
    private static final String PLACEHOLDER_URI = "localhost";
    /*third parameter in HTTP request*/
    private static final String HTTP_VERSION = "HTTP/1.1";
    /*text in the body of the request*/
    private static final String MSG = "Work, lads!";
    /*random free local port*/
    private static final int PORT = 8189;
    /*time the client should wait for a response*/
    private static final int TIMEOUT = 1000;
    /*client socket*/
    private static Socket socket;


    public static void main(String args[]) throws IOException {
        establishConnection();
        sendRequest();
        receiveResponse();
    }

    /**
     * Connects to the specified address and port of the server
     */
    private static void establishConnection() {
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(PLACEHOLDER_URI,PORT), TIMEOUT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sends an HTTP request, containing a header, newline and body
     */
    private static void sendRequest() {
        String request = REQUEST + " " + PLACEHOLDER_URI + " " + HTTP_VERSION + "\n"  + "\n" + MSG;
        try {
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
            writer.println(request);
            writer.println("end");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads a server's response and prints it on the console
     */
    private static void receiveResponse() {
        Scanner in;
        try {
            in = new Scanner(socket.getInputStream());
            while(in.hasNextLine()) {
                System.out.println(in.nextLine());
            }
            in.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



