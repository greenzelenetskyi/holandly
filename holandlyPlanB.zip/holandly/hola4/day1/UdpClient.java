package day1;

import java.io.IOException;
import java.net.*;

/**
 * File: UdpClient.java
 *
 * This is a simple udp client program, which connects with a server,
 * and sends a UDP packet with a message, and after it receives
 * the message back in other packet from the server, it terminates its operation.
 *
 * @author Andrii Zelenetskyi
 * @version 1.0
 */
public class UdpClient {

    /*random free local port*/
    private static final int PORT = 8189;
    /*text in the body of the request*/
    private static final String MSG = "Work, lads!";

    public static void main(String[] args) throws UnknownHostException {
        try(DatagramSocket socket = new DatagramSocket()) {
            while(true) {
                sendPacket(socket);
                receivePacket(socket);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sends a UDP packet with the message inside
     * @param socket client socket
     * @throws UnknownHostException
     */
    private static void sendPacket(DatagramSocket socket) throws UnknownHostException {
        byte[] sentBuffer;
        sentBuffer = MSG.getBytes();
        DatagramPacket packet = new DatagramPacket(sentBuffer, sentBuffer.length, InetAddress.getLocalHost(), PORT);
        try {
            socket.send(packet);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Receives a UDP packet with the server's response
     * @param socket local socket
     */
    private static void receivePacket(DatagramSocket socket) {
        DatagramPacket packet = new DatagramPacket(new byte[256], 256);
        try {
            socket.receive(packet);
            String received = new String(packet.getData(), 0, packet.getLength());
            System.out.println(received);
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
