package day1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * File: UdpServer.java
 *
 * This is a simple server program, which listens to clients' connections,
 * receives the UDP package with a message froma a client, and responds with the same message back.
 * The class uses java DatagramSocket class to listen to connections and
 * DatagramPacket class to retrieve a message and information about connection.
 * When "end" message is read, a client connection is stopped.
 *
 * @author Andrii Zelenetskyi
 * @version 1.0
 */
public class UdpServer {

    /*random free local port*/
    private static final int PORT = 8189;

    public static void main(String[] args) {
        byte[] receivedBuffer = new byte[256];
        byte[] sentBuffer;
        try {
            DatagramSocket socket = new DatagramSocket(PORT);
            DatagramPacket packet;
            while(true) {
                packet = new DatagramPacket(receivedBuffer, receivedBuffer.length);
                socket.receive(packet);
                sentBuffer = packet.getData();
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                packet = new DatagramPacket(sentBuffer, sentBuffer.length, address, port);
                socket.send(packet);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
