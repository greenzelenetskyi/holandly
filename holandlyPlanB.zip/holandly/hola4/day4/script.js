var storedEntries = localStorage.getItem("progress") ? JSON.parse(localStorage.getItem("progress")) : [];
todoCounter();


(function fillFromStorage() {
  if(storedEntries.length > 0) {
    storedEntries.forEach(function(entry) {
      saveEntry(entry.task, entry.check, true);
    });
  }
})();


function makeCustomEntry(text, isChecked) {
  let newEntry = document.createElement("div");
  let checkbox = document.createElement("input");
  let textfield = document.createElement("label");
  let cross = document.createElement("span");
  checkbox.setAttribute("type", "checkbox");
  if(isChecked) {checkbox.setAttribute("checked", true);}
  cross.textContent = "X";
  cross.setAttribute("style", "visibility:hidden; float:right;");
  newEntry.appendChild(checkbox);
  newEntry.appendChild(textfield);
  newEntry.appendChild(cross);
  newEntry.querySelector('label').textContent = text;
  if(isChecked) {
    newEntry.querySelector('label').style.textDecoration = "line-through";
  }
  document.getElementById("list_board").appendChild(newEntry);
  return newEntry;
}


function saveEntry (text, checked, isFromStorage) {
  let newEntry = makeCustomEntry(text, checked);
  addListeners(newEntry);
  addLabelListeners(newEntry.querySelector("label"));
  if(!isFromStorage) {
    storedEntries.push({task: newEntry.querySelector("label").textContent, check: false});
    refreshStorage();
    document.getElementById('textfield').value = "";
  }
};

function refreshStorage () {
  localStorage.setItem("progress", JSON.stringify(storedEntries));
  todoCounter();
}

function todoCounter() {
  var counter = 0;
  storedEntries.forEach(function(entry) {
    if(entry.check == false) {
      counter++;
    }
  });
  document.querySelector("#counter").textContent = counter;
}

document.addEventListener("keydown", function(event) {
  if(event.code === "Enter" && document.getElementById("textfield") === document.activeElement) {
    saveEntry(document.getElementById('textfield').value, false, false);
  }
});


function addListeners(listEntry) {
  listEntry.querySelector('input').addEventListener("input", function(event) {
    let label = event.target.nextElementSibling;
    if(event.target.checked === true) {
      label.style.textDecoration = "line-through";
      storedEntries.find(function(obj) {
        if(obj.task == label.textContent) {
          obj.check = true;
          return;
        }
      });
      refreshStorage();
    } else {
      label.style.textDecoration = "none";
      refreshStorage();
    }

  });
}


function addLabelListeners(label) {
  label.addEventListener("mouseover", function(event) {
      event.target.parentElement.querySelector("span").style.visibility = "visible";
  });

  label.addEventListener("mouseout", function(event) {
    event.target.parentElement.querySelector("span").style.visibility = "hidden";
  });

  label.addEventListener("dblclick", function(event) {
    let input = document.createElement("input");
    input.setAttribute("type", "text");
    let oldNode = event.target;
    event.target.replaceWith(input);
    document.addEventListener("keydown", function(event) {
      if(event.code == "Enter") {
        let newLabel = document.createElement("label");
        newLabel.textContent = event.target.value;
        storedEntries.find(function(obj) {
          if(obj.task == oldNode.textContent) {
            obj.task = newLabel.textContent;
            return;
          }
        });
        refreshStorage();
        /*todoCounter();*/
        input.replaceWith(newLabel);
        addLabelListeners(newLabel);
      }
    });
  });
}


document.querySelector("#check_all").addEventListener("input", function(event) {
  let allElements = document.querySelector("#list_board").getElementsByTagName('input');
    for(let i = 0; i < allElements.length; i++) {
      if(event.target.checked == true) {
        allElements.item(i).checked = true;
        allElements.item(i).parentElement.querySelector("label").style.textDecoration = "line-through";
        storedEntries[i].check = true;
      } else {
        allElements.item(i).checked = false;
        allElements.item(i).parentElement.querySelector("label").style.textDecoration = "none";
        storedEntries[i].check = false;
      }
    }
    /*todoCounter();*/
});


document.querySelector("#refresh_button").addEventListener("click", function(event) {
  let listEntries = document.querySelector("#list_board");
  listEntries.innerHTML = "";
  storedEntries = [];
  localStorage.clear();
  /*itemCount = 0;*/
});
