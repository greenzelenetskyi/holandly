function $(selector) {
  return new JQuery(document.querySelectorAll(selector));
}

class JQuery {
  constructor(nodeList) {
    this.nodeList = nodeList;
  }

  html(newHtml) {
    if(arguments.length == 0) {
      return this.nodeList.item(0).innerHTML;
    }
    this.nodeList.item(0).innerHTML = newHtml;
  }
}
