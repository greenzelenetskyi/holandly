/*This class is an implementation of least recently used cache.
It is responsible for storing cache entries in the order, in which
the least recently viewed items are at the beginning of the queue
and the most recent in the tail.
The get get, set and add operations are fast.
*/
class LruCache {
  var cache;
  var maxSize;
  var currentSize;
  var mostRecent;
  var leastRecent;

  constructor(size){
    cache = {};
    maxSize = size;
    currentSize = 0;
    mostRecent = null;
    leastRecent = null;
  }


  function pushToTail(key) {
    cache[key].previous = mostRecent;
    mostRecent.next = cache[key];
    mostRecent = cache[key];
    cache[key].next = null;
  }

  function removeFromCurrent(key) {
    if(cache[key].previous == leastRecent) {
      cache[key].next.previous = leastRecent;
      leastRecent = cache[key].next.previous;
    } else {
      cache[key].previous.next = cache[key].next;
      cache[key].next.previous = cache[key].previous;
    }
  }

  function get(key) {
    if(key in cache) {
      removeFromCurrent();
      pushToTail();
      return cache[key].value;
    }
    return null;
  }

  function set(key, newValue) {
    if(key in cache) {
      cache[key].value = newValue;
      removeFromCurrent(key);
      pushToTail(key);
    } else {
      add(key, newValue);
    }
  }

  function removeLeast() {
    let toDelete = leastRecent;
    leastRecent = leastRecent.next;
    delete toDelete;

  }

  function add(key, aValue) {
    if(!key in cache) {
      set(key, aValue);
      break;
    } else {
      cache[key].value = aValue;
      removeFromCurrent(key);
    }
    pushToTail(key);
    size++;
    if(leastRecent == null) {
      leastRecent = cache[key];
    }
    if(currentSize == maxSize) {
      removeLeast;
    }
  }
}
