
function $(selector) {
  var nodeList = document.querySelectorAll(selector);

  function html(newHtml) {
    var list = nodeList;
    if(arguments.length == 0) {
      return list.item(0).innerHTML;
    }
    list.item(0).innerHTML = newHtml;
  }

  return {
    html: html
  }
}
