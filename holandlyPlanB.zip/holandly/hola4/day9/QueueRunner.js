class QueueRunner {

  constructor(exec) {
    this.taskQueue = [];
    this.func = exec;
    this.isRunning = false;
    this.isPaused = false;
  }

  push(someData, someFunction) {
    this.taskQueue.push({data: someData, onFinish: someFunction});
    if(!this.isRunning) {
      this.runItems();
    }
  }

  pause() {
    this.isPaused = true;
  }

  resume() {
    this.isPaused = false;
    this.runItems();
  }

  cleanup() {
    this.taskQueue = [];
  }

  runItems() {
    this.isRunning = true;
    let context = this;
    function proc(){
      if(context.taskQueue.length <= 0) {
        context.isRunning = false;
      }
      if(!context.isPaused) {
        let entry = context.taskQueue.shift();
        context.func(entry.data, proc);
      }
    }

      proc();

  }

}
