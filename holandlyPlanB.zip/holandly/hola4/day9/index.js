let qr = new QueueRunner(function(data, onfinish) {
  setTimeout(function callback() {
    let elem = document.createElement('div');
    elem.textContent = "!!!";
    document.querySelector('body').appendChild(elem);
    onfinish();
  }, 5000);

});

for(let i = 0; i < 10; i++) {
  qr.push(i);
  if(i === 2) {
  }
}

setTimeout(function() {
  console.log("pause");
  qr.pause();
}, 10000);

setTimeout(function() {
  console.log("resume");
  qr.resume();
}, 20000);
