const http = require('http');
const WebSocket = require('ws');

var queue = [];
var isLocked = false;
var count = 0;


const server = new http.createServer({
});
const wss = new WebSocket.Server({ server });

wss.on('connection', function connection(ws) {
  console.log("connected to " + ws);
  queue.push(ws);
  if(!isLocked) {
    runCamera(queue.shift());
  }
});

function runCamera(socket, onfinish) {
  //console.log("start " + new Date().dateString);
  count++;
  socket.send(new Date().dateString + " " + count);
  isLocked = true;
  setTimeout(function() {
    console.log("finish " + new Date().dateString + " " + count);
    socket.send("finish");
    if(queue.length == 0) {
      runCamera(socket, onfinish);
    } else {
      runCamera(queue.shift());
    }
  }, 10000);
}


server.listen(8128, function() {
  console.log("running");
});
