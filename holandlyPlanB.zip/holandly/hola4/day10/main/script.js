loadPage();
var storedEntries = [];

/*
Retreives list data from the database on the server and saves to the array
*/
function loadPage() {
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", "/data/" + sessionStorage.getItem('name'), true);
  xhttp.send();
  xhttp.onreadystatechange = function(fillFromStorage) {
    if (this.readyState == 4 && this.status === 200) {
      showAccountUser()
      storedEntries = JSON.parse(this.responseText);
      todoCounter();
      (function fillFromStorage() {
        if(storedEntries.length > 0) {
          storedEntries.forEach(function(entry) {
            saveEntry(entry.task, entry.check, true);
          });
        }
      })();
    }
  };
}

/*
Saves entries either from a database or from user input
*/
function saveEntry (text, checked, isFromStorage) {
  let newEntry = makeCustomEntry(text, checked);
  addEntryListeners(newEntry);
  addLabelListeners(newEntry);
  if(!isFromStorage) {
    storedEntries.push({task: newEntry.querySelector("label").textContent, check: false});
    document.getElementById('textfield').value = "";
    postData();
  }
};

/*
Creates a list entry with default properties
*/
function makeCustomEntry(text, isChecked) {
  let newEntry = document.createElement("div");
  let checkbox = document.createElement("input");
  let textfield = document.createElement("label");
  let cross = document.createElement("span");
  checkbox.setAttribute("type", "checkbox");
  if(isChecked) {checkbox.setAttribute("checked", true);}
  cross.textContent = "X";
  cross.setAttribute("style", "visibility:hidden; float:right;");
  newEntry.appendChild(checkbox);
  newEntry.appendChild(textfield);
  newEntry.appendChild(cross);
  newEntry.querySelector('label').textContent = text;
  if(isChecked) {
    newEntry.querySelector('label').style.textDecoration = "line-through";
  }
  document.getElementById("list_board").appendChild(newEntry);
  return newEntry;
}

/*
Shows the account user name in the corner of the page
*/
function showAccountUser() {
  let user = document.createElement("p");
  user.textContent = sessionStorage.getItem("name") + " is logged in";
  document.querySelector('#account_user').innerHTML = "<p>" + sessionStorage.getItem("name") + " logged in" + "</p>";
}



/*Updates data in the database*/
function postData() {
  todoCounter();
  var xhr = new XMLHttpRequest();
  xhr.open("POST", '/data/' + sessionStorage.getItem('name'), true);
  xhr.setRequestHeader("Content-type", "text/plain");

  xhr.onreadystatechange = function() {
      if(this.readyState == XMLHttpRequest.DONE && this.status == 200) {
      }
  }
  let json = JSON.stringify(storedEntries);
  xhr.send(json);
}


/*
Counts unchecked entries in an array of entries
*/
function todoCounter() {
  var counter = 0;
  storedEntries.forEach(function(entry) {
    if(!entry.check) {
      counter++;
    }
  });
  document.querySelector("#counter").textContent = counter;
}

/*
Creates a list entry from user input
*/
document.addEventListener("keydown", function(event) {
  if(event.code === "Enter" && document.getElementById("textfield") === document.activeElement) {
    saveEntry(document.getElementById('textfield').value, false, false);
  }
});


function addEntryListeners(listEntry) {
  listEntry.querySelector('input').addEventListener("input", function(event) {
    let label = event.target.nextElementSibling;
    if(event.target.checked) {
      label.style.textDecoration = "line-through";

    } else {
      label.style.textDecoration = "none";
    }
    storedEntries.find(function(obj) {
      if(obj.task == label.textContent) {
        obj.check = event.target.checked;
        postData();
        return;
      }
    });
  });
}

/*
Adds listeners to the current entries for doubleclick change of the task content,
showing a delete cross on mouseover, and deleting on cross click
*/
function addLabelListeners(element) {
  element.addEventListener("mouseover", function(event) {
      event.target.querySelector("span").style.visibility = "visible";
  });

  element.addEventListener("mouseout", function(event) {
    event.target.querySelector("span").style.visibility = "hidden";
  });

  element.querySelector('span').addEventListener("click", function(event) {
    let index = storedEntries.findIndex(function(obj, index, storedEntries) {return obj.task == event.target.previousSibling.textContent});
    storedEntries.splice(index, 1);
    postData();
    element.outerHTML = "";
  });

  element.querySelector('label').addEventListener("dblclick", function(event) {
    let input = document.createElement("input");
    input.setAttribute("type", "text");
    let oldNode = event.target;
    event.target.replaceWith(input);
    document.addEventListener("keydown", function(event) {
      if(event.code == "Enter") {
        let newLabel = document.createElement("label");
        newLabel.textContent = event.target.value;
        storedEntries.find(function(obj) {
          if(obj.task == oldNode.textContent) {
            obj.task = newLabel.textContent;
            return;
          }
        });
        postData();
        input.replaceWith(newLabel);
        addLabelListeners(element);
      }
    });
  });
}


document.querySelector("#check_all").addEventListener("input", function(event) {
  let allElements = document.querySelector("#list_board").getElementsByTagName('input');
    for(let i = 0; i < allElements.length; i++) {
      if(event.target.checked) {
        allElements.item(i).parentElement.querySelector("label").style.textDecoration = "line-through";
      } else {
        allElements.item(i).parentElement.querySelector("label").style.textDecoration = "none";
      }
      allElements.item(i).checked = event.target.checked;
      storedEntries[i].check = event.target.checked;
    }
    postData();
});

document.querySelector("#refresh_button").addEventListener("click", function(event) {
  let listEntries = document.querySelector("#list_board");
  listEntries.innerHTML = "";
  storedEntries = [];
  postData();
});
