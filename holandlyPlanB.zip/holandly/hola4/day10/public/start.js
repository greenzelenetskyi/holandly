
$('#reg').click(function(event) {
  enterAccount(document.querySelector('#name').value, document.querySelector('#psw').value, '/register');
});

$('#log').click(function(event) {
  enterAccount(document.querySelector('#name').value, document.querySelector('#psw').value, '/login');
});

function enterAccount(uname, psw, action) {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", action, true);
  xhr.setRequestHeader("Content-type", "application/json");
  let json = JSON.stringify({name: uname, password: psw});
  sessionStorage.setItem("name", uname);
  xhr.send(json);

  xhr.onload = function () {
    if(xhr.status === 200) {
      window.location.href='/main/';
    };
  };
}
