var express = require('express');
var path = require('path');
var mysql = require('mysql');
var bodyParser = require('body-parser');
var app = express();


var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '0',
  database: "todos"
});

connection.connect(function(err){
if(!err) {
    console.log("Database is connected ... nn");
} else {
    console.log("Error connecting database ... nn");
}
});

app.use(express.static("public"));

//app.use(bodyParser.json());
app.use(bodyParser.text());

app.use(bodyParser.json());


app.get("/", function(req, res) {
  res.sendFile(__dirname + "/public/start.html")
})


app.get("/main", function(req, res) {
  console.log("hi");
  app.use(express.static("main"));
  res.sendFile(__dirname + "/main/index.html");
})
/*
Updates the database or creates new if not exists
*/
app.post("/data/*", function(req, res) {
  let data = JSON.parse(req.body);
  console.log(data);

  connection.query('TRUNCATE TABLE `'+req.params[0]+'`;', function(err, rows, fields) {
    if (!err)
      res.send();
    else
      console.log(err);
    });
  data.forEach(function(entry) {
    connection.query('INSERT INTO `'+req.params[0]+'` (`id`, `task`, `status`) VALUES (NULL,  "'+ entry.task +'", "'+ entry.check +'");', function(err, rows, fields) {
      if (!err)
        res.send();
      else
        console.log(err);
      });
  });
});

/*
Sends the database to a user
*/
app.get("/data/*", function(req, res) {
  console.log("slowpoke");
  let array = [];
  connection.query('SELECT * FROM todos.' + req.params[0] + ';', function(err, rows, fields) {
    if (!err) {
      console.log(rows);
      if(rows.length > 0) {
        rows.forEach(function(entry) {
          array.push({"task": entry.task, "check": entry.status === "true"});
        });
      }
      console.log(array);
      res.send(JSON.stringify(array));
    } else {
      console.log(err);
    }
    });
  });


/*
Registration of new users
*/
app.post('/register', function(req, res) {
  console.log('wanna register');
    var user = {
        name:req.body.name,
        password:req.body.password
    }
    connection.query('SELECT * FROM users WHERE name = ?', user.name, function(error, results, fields) {
      console.log("response: " + results);
      if(results.length > 0) {
        res.status(403);
      } else {
        connection.query('INSERT INTO users SET ?', user, function (error, results, fields) {
          if (error) {
            res.status(404);
          } else {
            connection.query('CREATE TABLE IF NOT EXISTS ' +user.name+ ' (id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, task TEXT, status VARCHAR(20));', function(err, rows, fields) {
            if (!err) {
              res.status(200).send();
            } else {
              res.status(404);
            }
          });
        }
      });
    }
  });
});



/*
Logging in
*/
app.post('/login', function (req,res, next) {
  console.log('wanna login');
    var name = req.body.name;
    var password = req.body.password;
    connection.query('SELECT * FROM users WHERE name = ?', [name], function (error, results, fields) {
      if (error) {
          console.log('error');
          res.status(404);
      } else if(results.length > 0 && password === results[0].password) {
          console.log('successfully logged in');
          res.status(200);
          return res.send();
      } else {
        console.log('User or password does not match');
        res.status(403);
      }
    });
  });

app.listen(8129, function() {
  console.log('wat up');
});
